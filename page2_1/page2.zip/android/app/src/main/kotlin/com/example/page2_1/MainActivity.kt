package com.example.page2_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
