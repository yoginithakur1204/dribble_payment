package com.example.page_linking_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
